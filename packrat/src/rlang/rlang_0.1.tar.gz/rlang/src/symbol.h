#ifndef RLANG_SYMBOL_H
#define RLANG_SYMBOL_H

extern SEXP sym_tilde;
extern SEXP sym_def;

#endif
